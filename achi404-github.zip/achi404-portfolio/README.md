# ARSHAD AYOOB — ACHI_404_

Cinematic game-style portfolio. Single-file site: open index.html.

Edit content in the `portfolioData`, `ASSETS` and `AUDIO` objects near the bottom of index.html.
